package main.repositories;

public interface PostsRepository {
}
