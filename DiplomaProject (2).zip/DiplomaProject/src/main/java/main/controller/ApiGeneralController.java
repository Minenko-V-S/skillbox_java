package main.controller;

import org.springframework.stereotype.Controller;

//todo
// для прочих запросов к API
@Controller
public class ApiGeneralController {
}
