package main.controller;

import org.springframework.stereotype.Controller;

//ToDo
// обрабатывает все запросы /api/post/*
@Controller
public class ApiPostController {
}
