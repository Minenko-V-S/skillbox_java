package main.controller;

import org.springframework.stereotype.Controller;

//todo
// обрабатывает все запросы /api/auth/*
@Controller
public class ApiAuthController {
}
