package main.config;

public class Config {
    public static final String STRING_MULTIUSER_MODE = "Многопользовательский режим";
    public static final String STRING_POST_PREMODERATION = "Премодерация постов";
    public static final String STRING_STATISTICS_IS_PUBLIC = "Показывать всем статистику блога";

    public static final String STRING_YES = "Да";
    public static final String STRING_NO = "Нет";
}
