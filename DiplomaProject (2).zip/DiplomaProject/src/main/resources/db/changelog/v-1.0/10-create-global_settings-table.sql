INSERT INTO global_settings ( code, name, value) VALUES
( 'MULTIUSER_MODE', 'Многопользовательский режим', 'NO'),
('POST_PREMODERATION', 'Премодерация постов', 'YES'),
( 'STATISTICS_IS_PUBLIC', 'Показывать всем статистику блога', 'YES');